# LowkeyCreator AI

LowkeyCreator AI, sosyal medya içerik üreticileri için hızlı fikir ve planlama aracı.

## Özellikler
- Konuya göre içerik fikirleri üretir
- Instagram & TikTok uyumlu öneriler
- Türkçe & İngilizce destek

## Lisans
© 2025 LowkeyCreator AI. Bu yazılımın izinsiz kopyalanması, dağıtılması veya ticari olarak kullanılması yasaktır.